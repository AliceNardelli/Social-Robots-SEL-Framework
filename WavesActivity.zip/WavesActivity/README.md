# WavesActivity

An Android application for a social robot used in a social and emotional
learning (SEL) activity with primary-school children.

The robot introduces itself, tells the stories of three waves coming from the
Atlantic Ocean, the Mediterranean Sea and the Caribbean Sea, and then holds an
open conversation with the children about the emotions those stories evoke. A
lightweight episodic memory keeps a running summary of the activities and
feelings a class has shared, and feeds it back into the dialogue system.

## Structure

| Path | Purpose |
| --- | --- |
| `MainActivity.java` | Session flow: introduction, three wave stories, open dialogue |
| `RobotController.java` | Head motors, wheels and built-in emotional behaviours |
| `EpisodicMemory.java` | Detects and extracts preferences and feelings, maintains the class summary |
| `OpenAIClient.java` | Chat completions client |
| `BIReader.java` | Plays pre-recorded interactive behaviours |
| `VideoPlayer.java` | Optional video playback with runtime permissions |
| `WeatherService.java` / `WeatherResponse.java` | Optional weather lookup |
| `res/raw/config_dialog.yaml` | System prompt and episodic-memory prompts |
| `assets/dialogue.json`, `assets/emotions.json` | Scripted fallback answers and their emotions |

## Credentials

No credential is stored in this repository. All keys are read at build time
from `local.properties` and exposed through `BuildConfig`:

1. Copy `local.properties.example` to `local.properties` and fill in your own
   `OPENAI_API_KEY`, `OPENAI_ORGANIZATION_ID`, `AZURE_SPEECH_KEY`,
   `AZURE_SPEECH_REGION` and `WEATHER_API_KEY`.
2. Copy `credentials.gradle.example` to `credentials.gradle` and fill in the
   Maven credentials for the robot SDK repository, or export them as the
   `BFR_MAVEN_USER` and `BFR_MAVEN_PASSWORD` environment variables.

Both files are listed in `.gitignore`. The project builds with empty keys; the
speech and dialogue features simply fail at runtime until keys are supplied.

## Speech

Recognition uses automatic source-language detection over `en-US` and `en-GB`.
Synthesis uses three Azure neural voices: `en-US-AvaMultilingualNeural` for the
robot, `en-US-EmmaNeural` for the waves and `en-US-AndrewNeural` for the
narrator. They are set in `MainActivity.sayText`.

## Data written on the device

Session logs are written to the app-specific external files directory, under
`LogFiles/`:

- `wavesactivity_<date>_sentence.txt` — recognized utterances and robot replies
- `wavesactivity_<date>_timestamp.txt` — touch-sensor events
- `episodic_memory.txt` — the running summary for the current class

These files may contain what children said during a session. Handle, store and
delete them according to the ethical approval and data-management plan of your
study.
