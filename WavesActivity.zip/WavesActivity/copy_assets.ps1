# Copies the binary assets (images, wave sounds, launcher icons, Gradle
# wrapper) from the original project into WavesActivity, applying the English
# file names the code now refers to.
#
# Usage, from the folder that contains both projects:
#   powershell -ExecutionPolicy Bypass -File WavesActivity\copy_assets.ps1
#
# Adjust $Src if the original project lives elsewhere.

$Src = Join-Path $PSScriptRoot "..\ApplicazioneOndeC4"
$Dst = $PSScriptRoot

if (-not (Test-Path $Src)) {
    Write-Error "Original project not found at $Src"
    exit 1
}

# drawable: renamed to English
$drawables = @{
    "onde.jpg"          = "waves.jpg"
    "io.png"            = "introduction.png"
    "oceano.jpg"        = "ocean.jpg"
    "mediterraneo.jpg"  = "mediterranean.jpg"
    "caraibi.jpg"       = "caribbean.jpg"
    "start.png"         = "start.png"
    "stopp.png"         = "stop.png"
    "ahead.png"         = "ahead.png"
    "back.png"          = "back.png"
}
$drawableSrc = Join-Path $Src "app\src\main\res\drawable"
$drawableDst = Join-Path $Dst "app\src\main\res\drawable"
New-Item -ItemType Directory -Force -Path $drawableDst | Out-Null
foreach ($k in $drawables.Keys) {
    Copy-Item (Join-Path $drawableSrc $k) (Join-Path $drawableDst $drawables[$k]) -Force
}
Copy-Item (Join-Path $drawableSrc "ic_launcher_background.xml") $drawableDst -Force

# raw: wave sounds, renamed to English
$raws = @{
    "onda_atlantica.mp3"    = "wave_atlantic.mp3"
    "onda_mediterranea.mp3" = "wave_mediterranean.mp3"
    "onda_pacifica.mp3"     = "wave_caribbean.mp3"
}
$rawSrc = Join-Path $Src "app\src\main\res\raw"
$rawDst = Join-Path $Dst "app\src\main\res\raw"
New-Item -ItemType Directory -Force -Path $rawDst | Out-Null
foreach ($k in $raws.Keys) {
    Copy-Item (Join-Path $rawSrc $k) (Join-Path $rawDst $raws[$k]) -Force
}

# launcher icons and the adaptive-icon foreground, copied unchanged
foreach ($d in @("drawable-v24", "mipmap-anydpi-v26", "mipmap-hdpi", "mipmap-mdpi",
                 "mipmap-xhdpi", "mipmap-xxhdpi", "mipmap-xxxhdpi")) {
    $from = Join-Path $Src "app\src\main\res\$d"
    $to   = Join-Path $Dst "app\src\main\res\$d"
    New-Item -ItemType Directory -Force -Path $to | Out-Null
    Copy-Item (Join-Path $from "*") $to -Recurse -Force
}

# Gradle wrapper
$gwSrc = Join-Path $Src "gradle\wrapper"
$gwDst = Join-Path $Dst "gradle\wrapper"
New-Item -ItemType Directory -Force -Path $gwDst | Out-Null
Copy-Item (Join-Path $gwSrc "*") $gwDst -Force
Copy-Item (Join-Path $Src "gradlew")     $Dst -Force
Copy-Item (Join-Path $Src "gradlew.bat") $Dst -Force

Write-Host "Assets copied into $Dst"
