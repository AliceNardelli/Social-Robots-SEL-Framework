package com.example.wavesactivity;

import android.util.Log;

import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

/**
 * Keeps a running summary of what a class has told the robot: the activities
 * the children say they like and the feelings they express. The summary is
 * stored on the device and injected back into the dialogue system message.
 */
public class EpisodicMemory {

    /** Name of the file holding the episodic memory of the current class. */
    private static final String MEMORY_FILE_NAME = "episodic_memory.txt";

    private OpenAIClient openAIClient;
    private File dir;
    private Map<String, String> configMap;
    private ArrayList<String> sentences = new ArrayList<>();

    public EpisodicMemory(OpenAIClient client, File dir, Map<String, String> configMap) {
        this.openAIClient = client;
        this.dir = dir;
        this.configMap = configMap;
    }

    // =========================
    // TEMPLATE FILLER
    // =========================
    private String fillTemplate(String template, Map<String, String> values) {
        for (Map.Entry<String, String> entry : values.entrySet()) {
            String value = entry.getValue() == null ? "" : entry.getValue();
            template = template.replace("{" + entry.getKey() + "}", value);
        }
        return template;
    }

    // =========================
    // ASYNC GPT CALL
    // =========================
    private void callGPT(String text, String systemMessage, GPTCallback callback) {

        openAIClient.queryGPT2(text, systemMessage, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                callback.onResult("");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    String body = response.body().string();
                    String result = parseResponse(body);
                    callback.onResult(result);
                } catch (Exception e) {
                    e.printStackTrace();
                    callback.onResult("");
                }
            }
        });
    }

    private String parseResponse(String response) {
        try {
            JSONObject json = new JSONObject(response);
            return json.getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    // =========================
    // PROMPT FUNCTIONS
    // =========================
    private void detectPreferredActivities(String text, GPTCallback callback) {
        String template = configMap.get("detect_preferred_activities");
        callGPT(text, template, callback);
    }

    private void detectFeelings(String text, GPTCallback callback) {
        String template = configMap.get("detect_feelings");
        callGPT(text, template, callback);
    }

    private void extractPreferredActivities(String text, GPTCallback callback) {
        String template = configMap.get("extract_preferred_activities");
        callGPT(text, template, callback);
    }

    private void extractFeelings(String text, GPTCallback callback) {
        String template = configMap.get("extract_feelings");
        callGPT(text, template, callback);
    }

    private void updateEpisodes(String previousSummary, String newInfo, GPTCallback callback) {
        String template = configMap.get("update_episodes");
        Map<String, String> values = new HashMap<>();
        values.put("PREVIOUS_SUMMARY", previousSummary);
        values.put("NEW_INFO", newInfo);
        String systemMessage = fillTemplate(template, values);
        callGPT(newInfo, systemMessage, callback);
    }

    // =========================
    // PIPELINE (CALLED FROM MAINACTIVITY)
    // =========================
    public void runPipeline(String userInput) {
        new Thread(() -> {
            String previousSummary = loadPreviousSummary();
            StringBuilder newInfo = new StringBuilder();
            sentences.add(userInput);
            if (sentences.size() > 4) {
                sentences.remove(0);  // removes the first element
            }
            // 1. Detect preferences
            detectPreferredActivities(userInput, detectedPref -> {
                Log.i("DETECT PREFERRED", detectedPref);
                if (detectedPref.equalsIgnoreCase("true")) {
                    extractPreferredActivities(userInput, extractedPref -> {
                        Log.i("EXTRACT PREFERRED", extractedPref);
                        if (!extractedPref.isEmpty()) {
                            newInfo.append(extractedPref).append("\n");
                        }
                        // After preference extraction, detect feelings
                        detectFeelingsStep(sentences.toString(), newInfo, previousSummary);
                    });
                } else {
                    detectFeelingsStep(sentences.toString(), newInfo, previousSummary);
                }
            });
        }).start();
    }

    // Detect feelings then extract them if present
    private void detectFeelingsStep(String userInput, StringBuilder newInfo, String previousSummary) {
        Log.i("NEW INFO", String.valueOf(newInfo));
        detectFeelings(userInput, detectedFeelings -> {
            Log.i("DETECT FEELINGS", detectedFeelings);
            if (detectedFeelings.equalsIgnoreCase("true")) {
                extractFeelings(userInput, extractedFeelings -> {
                    if (!extractedFeelings.isEmpty()) {
                        Log.i("EXTRACT FEELINGS", extractedFeelings);
                        newInfo.append(extractedFeelings).append("\n");
                    }
                    finalizeUpdate(newInfo, previousSummary);
                });
            } else {
                finalizeUpdate(newInfo, previousSummary);
            }
        });
    }

    private void finalizeUpdate(StringBuilder newInfo, String previousSummary) {
        Log.i("NEW INFO", String.valueOf(newInfo));
        if (newInfo.length() > 0) {
            updateEpisodes(previousSummary, newInfo.toString(), updatedSummary -> saveToFile(updatedSummary));
        } else {
            saveToFile(previousSummary);
        }
    }

    private String loadPreviousSummary() {
        try {
            File file = new File(dir, MEMORY_FILE_NAME);
            if (!file.exists()) return "";

            java.util.Scanner scanner = new java.util.Scanner(file);
            StringBuilder content = new StringBuilder();
            while (scanner.hasNextLine()) {
                content.append(scanner.nextLine()).append("\n");
            }
            scanner.close();
            return content.toString().trim();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private void saveToFile(String summary) {
        try {
            File file = new File(dir, MEMORY_FILE_NAME);
            FileWriter writer = new FileWriter(file, false);
            writer.write(summary);
            writer.close();
            Log.i("EpisodicMemory", "Summary saved");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public interface GPTCallback {
        void onResult(String result);
    }
}
