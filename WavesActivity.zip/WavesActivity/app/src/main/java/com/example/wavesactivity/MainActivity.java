package com.example.wavesactivity;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.util.concurrent.Future;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.bfr.buddy.ui.shared.FacialEvent;
import com.bfr.buddy.ui.shared.FacialExpression;
import com.bfr.buddy.ui.shared.LabialExpression;
import com.bfr.buddysdk.BuddyActivity;
import com.bfr.buddysdk.BuddySDK;

import com.microsoft.cognitiveservices.speech.ResultReason;
import com.microsoft.cognitiveservices.speech.SpeechConfig;
import com.microsoft.cognitiveservices.speech.SpeechRecognizer;
import com.microsoft.cognitiveservices.speech.SpeechRecognitionResult;
import com.microsoft.cognitiveservices.speech.AutoDetectSourceLanguageConfig;
import com.microsoft.cognitiveservices.speech.SpeechSynthesisResult;
import com.microsoft.cognitiveservices.speech.SpeechSynthesizer;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.yaml.snakeyaml.Yaml;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

/**
 * Main activity of the WavesActivity application.
 *
 * The robot introduces itself, tells the stories of three waves coming from
 * different seas and oceans, and then holds an open conversation with the
 * children about the emotions those stories evoke.
 *
 * All credentials are read from BuildConfig, which is populated at build time
 * from local.properties (see local.properties.example). No key is stored in
 * this repository.
 */
public class MainActivity extends BuddyActivity {

    /** Azure Cognitive Services speech key, injected at build time. */
    private static final String SUBSCRIPTION_KEY = BuildConfig.AZURE_SPEECH_KEY;
    /** Azure Cognitive Services region, injected at build time. */
    private static final String SERVICE_REGION = BuildConfig.AZURE_SPEECH_REGION;

    private static final int PERMISSIONS_REQUEST_RECORD_AUDIO = 1;

    /** Name of the file holding the episodic memory of the current class. */
    private static final String MEMORY_FILE_NAME = "episodic_memory.txt";

    private ImageButton button_start;
    private ImageButton button_stop;
    private ImageButton button_introduction;
    private ImageButton button_activity;
    private ImageButton button_go;
    private ImageButton button_back;
    private ImageView imageView;
    private ImageView imageView_1;
    private ImageView imageView_2;
    private ImageView imageView_3;
    private SpeechRecognizer recognizer;
    private RobotController robotController;
    private OpenAIClient openAIClient;
    private String systemMessage;
    JsonLoader jsonLoader;
    private Handler handler;
    private String recognizer_state;
    private String recognizer_activated;
    private String speaking;
    private long lastFaceChangeTime;
    private String recognized_sentence;
    private JSONArray history_messages;
    private MediaPlayer mediaPlayer;
    private Boolean next;
    private Boolean feedback;
    EpisodicMemory memory;
    private File dir1;
    private Boolean activity_going;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        jsonLoader = new JsonLoader();
        handler = new Handler();
        // Request microphone permission if not already granted
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSIONS_REQUEST_RECORD_AUDIO);
        } else {
            initializeRecognizer();
        }
        robotController = new RobotController();
    }

    @Override
    public void onSDKReady() {

        // transfer the touch information to the robot core in the background
        BuddySDK.UI.setViewAsFace(findViewById(R.id.view_face));
        button_start = findViewById(R.id.buttonstart);
        button_start.setOnClickListener(view -> {
            recognizer_state = "active";
            activate_recognizer();
        });
        button_stop = findViewById(R.id.buttonstop);
        button_stop.setOnClickListener(view -> {
            recognizer_state = "stopped";
        });
        button_introduction = findViewById(R.id.buttonintroduction);
        button_introduction.setOnClickListener(view -> {
            recognizer_state = "stopped";
            introduction();
        });

        button_activity = findViewById(R.id.buttonactivity);
        button_activity.setOnClickListener(view -> {
            recognizer_state = "stopped";
            start_wave_activity();
        });

        button_go = findViewById(R.id.buttongo);
        button_go.setOnClickListener(view -> end_wave_activity());

        button_back = findViewById(R.id.buttonback);
        button_back.setOnClickListener(view -> {
            show_items();
        });

        imageView = findViewById(R.id.imageView);

        imageView_1 = findViewById(R.id.iv1);
        imageView_1.setOnClickListener(view -> show_item1());

        imageView_2 = findViewById(R.id.iv2);
        imageView_2.setOnClickListener(view -> show_item2());

        imageView_3 = findViewById(R.id.iv3);
        imageView_3.setOnClickListener(view -> show_item3());

        Map<String, String> config = loadConfigFromYaml();

        recognizer_state = "active";
        recognizer_activated = "False";
        speaking = "False";
        recognized_sentence = "";
        history_messages = new JSONArray();
        lastFaceChangeTime = 0;
        next = false;
        feedback = false;
        activity_going = true;

        if (config != null) {
            systemMessage = config.get("system_message2");
            Log.i("info", "system message loaded");
        } else {
            Log.e("info", "Failed to load configuration.");
        }
        // Credentials are injected at build time, never stored in the configuration file.
        openAIClient = new OpenAIClient(BuildConfig.OPENAI_API_KEY, BuildConfig.OPENAI_ORGANIZATION_ID);

        Map<String, String> configMap = loadConfigFromYaml();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            dir1 = new File(getExternalFilesDir(null), "LogFiles"); // No permissions required
        } else {
            dir1 = new File(Environment.getExternalStorageDirectory(), "LogFiles");
        }
        memory = new EpisodicMemory(
                openAIClient,
                dir1,
                configMap
        );
        imageView_1.setVisibility(View.GONE);
        imageView_2.setVisibility(View.GONE);
        imageView_3.setVisibility(View.GONE);
        robotController.start_autonomous_head_movements();
        startBodyTouchSensorCheck();
        start_autonomous_life();
    }

    private void playSound(int resourceId) {
        // Release the previous MediaPlayer if it exists
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null; // Set to null to avoid memory leaks
        }

        mediaPlayer = MediaPlayer.create(this, resourceId);
        if (mediaPlayer != null) {
            mediaPlayer.start();

            // Stop and release after 5 seconds
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (mediaPlayer != null) {
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.stop(); // Stop playback if playing
                    }
                    mediaPlayer.release(); // Release resources
                    mediaPlayer = null; // Set to null to avoid memory leaks
                }
            }, 5000); // 5000 milliseconds = 5 seconds

            mediaPlayer.setOnCompletionListener(mp -> {
                if (mp != null) {
                    mp.release();
                }
                mediaPlayer = null; // Set to null to avoid memory leaks
            });
        } else {
            Log.e("INFO", "Failed to create MediaPlayer");
        }
    }

    private String fillTemplate_main(String template, Map<String, String> values) {
        for (Map.Entry<String, String> entry : values.entrySet()) {
            String value = entry.getValue() == null ? "" : entry.getValue();
            template = template.replace("{" + entry.getKey() + "}", value);
        }
        return template;
    }

    String loadMemory() {
        try {
            File file = new File(dir1, MEMORY_FILE_NAME);
            if (!file.exists()) return "";

            java.util.Scanner scanner = new java.util.Scanner(file);
            StringBuilder content = new StringBuilder();
            while (scanner.hasNextLine()) {
                content.append(scanner.nextLine()).append("\n");
            }
            scanner.close();
            return content.toString().trim();
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private void save_timestamp() {

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                Log.e("error", "NO PERMISSION");
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return; // Stop execution here, wait for permission result
            }
        }

        // Get current timestamp
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String timestamp = now.format(formatter);

        // Extract year, month, and day for filename
        int year = now.getYear();
        int month = now.getMonthValue();
        int day = now.getDayOfMonth();

        File dir;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            dir = new File(getExternalFilesDir(null), "LogFiles"); // No permissions required
        } else {
            dir = new File(Environment.getExternalStorageDirectory(), "LogFiles");
        }

        // Ensure the directory exists
        if (!dir.exists() && !dir.mkdirs()) {
            System.out.println("Failed to create directory!");
            return;
        }

        // Create file in the directory
        File file = new File(dir, String.format("wavesactivity_%d_%02d_%02d_timestamp.txt", year, month, day));

        // Write timestamp to file
        try (FileWriter writer = new FileWriter(file, true)) { // true = append mode
            writer.write(timestamp + "\n");
            writer.flush(); // Ensure it's written
            System.out.println("Timestamp saved at: " + file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void save_sentence(String sentence) {
        // Check and request WRITE_EXTERNAL_STORAGE permission (for Android < 10)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) { // Android 9 or lower
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return; // Exit function to wait for permission response
            }
        }

        // Get current timestamp
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String timestamp = now.format(formatter);

        // Extract year, month, and day for filename
        int year = now.getYear();
        int month = now.getMonthValue();
        int day = now.getDayOfMonth();

        // Use app-specific storage directory (no permissions required on Android 10+)
        File dir;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            dir = new File(getExternalFilesDir(null), "LogFiles");
        } else {
            dir = new File(Environment.getExternalStorageDirectory(), "LogFiles");
        }

        // Ensure directory exists
        if (!dir.exists() && !dir.mkdirs()) {
            System.out.println("Failed to create directory!");
            return;
        }

        // Create file in the directory
        File file = new File(dir, String.format("wavesactivity_%d_%02d_%02d_sentence.txt", year, month, day));

        // Write timestamp and sentence to file
        try (FileWriter writer = new FileWriter(file, true)) { // true = append mode
            writer.write(timestamp + " " + sentence + "\n");
            writer.flush(); // Ensure it's written
            System.out.println("Sentence saved: " + timestamp + " " + sentence);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void start_autonomous_life() {
        button_start.setVisibility(View.VISIBLE);
        button_stop.setVisibility(View.VISIBLE);
        button_activity.setVisibility(View.VISIBLE);
        button_introduction.setVisibility(View.VISIBLE);
        button_back.setVisibility(View.GONE);
        button_go.setVisibility(View.GONE);
        recognizer_state = "active";
        activate_recognizer();
    }

    private void show_items() {
        recognizer_state = "stopped";
        button_start.setVisibility(View.GONE);
        button_stop.setVisibility(View.GONE);
        button_activity.setVisibility(View.GONE);
        button_introduction.setVisibility(View.GONE);
        button_back.setVisibility(View.GONE);
        set_emotion("Neutral");
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            button_go.setVisibility(View.VISIBLE);
            imageView_1.setVisibility(View.VISIBLE);
            imageView_2.setVisibility(View.VISIBLE);
            imageView_3.setVisibility(View.VISIBLE);
        }, 1000);
    }

    /** Opening of the activity: the robot introduces the theme of the waves. */
    private void start_wave_activity() {
        button_start.setVisibility(View.GONE);
        button_stop.setVisibility(View.GONE);
        button_activity.setVisibility(View.GONE);
        button_introduction.setVisibility(View.GONE);
        recognizer_state = "stopped";
        activity_going = false;
        set_emotion("Neutral");
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            sayText("I imagine that I am a wave that keeps changing. At first I am small and calm, but as I grow I get restless and become powerful!", "robot");
            set_emotion("Happy");
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                set_emotion("Neutral");
                sayText("I would like to tell you the stories of some waves that form every day in the seas and the oceans of our beautiful planet.", "robot");
                sayText("Would you like to know who they are and what they feel?", "robot");
                wait_touch();
                show_items();
            }, 3000);
        }, 1000);
    }

    /** First story: the wave of the Atlantic Ocean. */
    private void show_item1() {
        button_go.setVisibility(View.GONE);
        imageView_1.setVisibility(View.GONE);
        imageView_2.setVisibility(View.GONE);
        imageView_3.setVisibility(View.GONE);
        set_emotion("Neutral");
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            sayText("The wave from the Atlantic Ocean tells us:", "robot");
            sayText("When I am born, the wind carries me for thousands of kilometres across my home of salt water. I feel full of energy, and I carry my power along, following the wind that blows.", "wave");
            set_emotion("Happy");
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                set_emotion("Neutral");
                sayText("After wandering in the ocean for a long time, I come close to the high cliffs, and there I grow furious.", "wave");
                set_emotion("Angry");
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    set_emotion("Neutral");
                    sayText("I rise very high, until I crash against the rocks and return to my home.", "wave");
                    imageView.setImageResource(R.drawable.ocean);
                    imageView.setVisibility(View.VISIBLE);
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        playSound(R.raw.wave_atlantic);
                        wait_touch();
                        imageView.setVisibility(View.GONE);
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            sayText("Have you ever felt like a furious wave of the ocean too?", "robot");
                            wait_touch();
                            lets_play_together();
                        }, 500);
                    }, 500);
                }, 3000);
            }, 3000);
        }, 1000);
    }

    /** Second story: the wave of the Mediterranean Sea. */
    private void show_item2() {
        button_go.setVisibility(View.GONE);
        imageView_1.setVisibility(View.GONE);
        imageView_2.setVisibility(View.GONE);
        imageView_3.setVisibility(View.GONE);
        set_emotion("Neutral");
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            sayText("The wave from the Mediterranean Sea tells us:", "robot");
            sayText("I feel different emotions as I grow. I am born when the Mistral wind blows over the sea, and at first I feel serene.", "wave");
            set_emotion("Happy");
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                set_emotion("Neutral");
                sayText("I soon reach the coast, where I find beaches of pebbles or sharp rocks, and they make me a little restless.", "wave");
                set_emotion("Scared");
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    set_emotion("Neutral");
                    sayText("As I come closer, I like to curl up and dissolve into my white foam.", "wave");
                    imageView.setImageResource(R.drawable.mediterranean);
                    imageView.setVisibility(View.VISIBLE);
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        playSound(R.raw.wave_mediterranean);
                        wait_touch();
                        imageView.setVisibility(View.GONE);
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            sayText("I think I can hear the wave of the sea. And have you felt different emotions too?", "robot");
                            wait_touch();
                            lets_play_together();
                        }, 500);
                    }, 500);
                }, 3000);
            }, 3000);
        }, 1000);
    }

    /** Third story: the wave of the Caribbean Sea. */
    private void show_item3() {
        button_go.setVisibility(View.GONE);
        imageView_1.setVisibility(View.GONE);
        imageView_2.setVisibility(View.GONE);
        imageView_3.setVisibility(View.GONE);
        set_emotion("Neutral");
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            sayText("The wave from the Caribbean Sea tells us:", "robot");
            sayText("I am born in a home of crystal-clear water that wraps me in a warm embrace.", "wave");
            set_emotion("Love");
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                set_emotion("Neutral");
                sayText("When the tropical wind carries me along, I stay very calm and peaceful. Then I reach the beaches of golden sand, and I lie down with my long white foam, going back to be cradled by my warm sea.", "wave");
                set_emotion("Happy");
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    set_emotion("Neutral");
                    imageView.setImageResource(R.drawable.caribbean);
                    imageView.setVisibility(View.VISIBLE);
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        playSound(R.raw.wave_caribbean);
                        wait_touch();
                        imageView.setVisibility(View.GONE);
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            sayText("What a very calm wave! Have you ever felt this peaceful too?", "robot");
                            wait_touch();
                            lets_play_together();
                        }, 500);
                    }, 500);
                }, 3000);
            }, 3000);
        }, 1000);
    }

    /** Open conversation phase that follows each story. */
    private void lets_play_together() {
        button_start.setVisibility(View.VISIBLE);
        button_stop.setVisibility(View.VISIBLE);
        button_back.setVisibility(View.VISIBLE);
        recognizer_state = "active";
        activate_recognizer();
    }

    /** Closing of the activity: the robot sums up what the three waves share. */
    private void end_wave_activity() {
        button_go.setVisibility(View.GONE);
        imageView_1.setVisibility(View.GONE);
        imageView_2.setVisibility(View.GONE);
        imageView_3.setVisibility(View.GONE);
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            sayText("What wonderful stories we have listened to! Every wave feels different emotions: there is the one that is happy when the wind blows hard, and the one that gets angry when it comes close to the rocks. And yet every wave shares the same story: wherever the wind blows, the wave follows it!", "robot");
            feedback = true;
            activity_going = true;
            start_autonomous_life();
        }, 1000);
    }

    private void startBodyTouchSensorCheck() {
        // Create and start a new thread to run the task
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(500); // Delay of 500ms
                    checkBodyTouchAndReact();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void select_face() {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFaceChangeTime < 4000) {
            return; // too soon, do nothing
        }
        lastFaceChangeTime = currentTime; // update the timestamp
        Random random = new Random();
        int randomNumber = random.nextInt(6);
        if (randomNumber == 0) BuddySDK.UI.setFacialExpression(FacialExpression.HAPPY);
        else if (randomNumber == 1) BuddySDK.UI.setFacialExpression(FacialExpression.THINKING);
        else if (randomNumber == 2) BuddySDK.UI.setFacialExpression(FacialExpression.SURPRISED);
        else BuddySDK.UI.setFacialExpression(FacialExpression.LOVE);
    }

    private void checkBodyTouchAndReact() {
        if (BuddySDK.Sensors.BodyTouchSensors().RightShoulder().isTouched()
                || BuddySDK.Sensors.BodyTouchSensors().LeftShoulder().isTouched()
                || BuddySDK.Sensors.BodyTouchSensors().Torso().isTouched()
                || (BuddySDK.Sensors.HeadTouchSensors().Top().isTouched()
                || BuddySDK.Sensors.HeadTouchSensors().Left().isTouched()
                || BuddySDK.Sensors.HeadTouchSensors().Right().isTouched())
        ) {
            save_timestamp();
            if (activity_going) {
                select_face();
            }
            next = true;
            if (feedback) {
                String[] phrases = {
                        "What intense emotions your waves convey!",
                        "So much emotion can be felt in your waves!",
                        "Your waves stir up incredible emotions!",
                        "What deep feelings your waves carry!",
                        "It is amazing how many emotions your waves give off!"
                };

                Random random = new Random();
                sayText(phrases[random.nextInt(phrases.length)], "robot");
            }
            Log.i("info", "TOUCHED");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        robotController.stop_autonomous_movement();
        recognizer_state = "stopped";
        handler.removeCallbacksAndMessages(null);  // Stop the handler when the activity is destroyed
    }

    private Map<String, String> loadConfigFromYaml() {
        try {
            // Load the YAML file from res/raw
            InputStream inputStream = getResources().openRawResource(R.raw.config_dialog);
            Yaml yaml = new Yaml();
            return yaml.load(inputStream); // Load YAML data into a Map
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Return null in case of failure
        }
    }

    private void wait_touch() {
        next = false;
        while (!next) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Log.i("main", "Thread interrupted", e);
            }
        }
        next = false;
    }

    /** Self-introduction of the robot at the beginning of a session. */
    private void introduction() {
        button_start.setVisibility(View.GONE);
        button_stop.setVisibility(View.GONE);
        button_introduction.setVisibility(View.GONE);
        button_activity.setVisibility(View.GONE);
        recognizer_state = "stopped";
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            sayText("Hello, I am Buddy. I come from a research laboratory, a place where I stay with other robots and with my engineer friends, who take care of me.", "robot");
            sayText("I came here to your school to explore emotions together with you and to meet friends like you.", "robot");
            sayText("I really like art, music and history, and I am curious to explore the beautiful things in nature, such as the sea, the sky and the trees.", "robot");
            sayText("I bring many stories with me to tell you as a gift. I am happy to be here and I would like to discover your passions and your curiosities.", "robot");
            sayText("And what are your names?", "robot");
            wait_touch();
            sayText("What beautiful names! And what do you like to do?", "robot");
            start_autonomous_life();
        }, 1000);
    }

    private void initializeRecognizer() {
        SpeechConfig config = SpeechConfig.fromSubscription(SUBSCRIPTION_KEY, SERVICE_REGION);
    }

    private void recognizeSpeechOnce() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSIONS_REQUEST_RECORD_AUDIO);
        } else {
            initializeRecognizer();
        }
        try {
            recognizer_activated = "True";
            SpeechConfig config = SpeechConfig.fromSubscription(SUBSCRIPTION_KEY, SERVICE_REGION);
            List<String> languages = Arrays.asList("en-US", "en-GB");
            AutoDetectSourceLanguageConfig autoDetectSourceLanguageConfig = AutoDetectSourceLanguageConfig.fromLanguages(languages);

            recognizer = new SpeechRecognizer(config, autoDetectSourceLanguageConfig);

            // Recognize speech once and handle it synchronously
            Future<SpeechRecognitionResult> futureResult = recognizer.recognizeOnceAsync();

            // Wait for the result to be available
            SpeechRecognitionResult result = futureResult.get();

            if (result.getReason() == ResultReason.RecognizedSpeech) {
                save_sentence("user: " + result.getText());
                Log.i("info", "Recognized: " + result.getText());
                recognized_sentence = result.getText();
                recognizer_activated = "False";
                memory.runPipeline(result.getText());
                if (!recognizer_state.equals("stopped")) askGPTResponse(result.getText());
            } else if (result.getReason() == ResultReason.NoMatch) {
                Log.i("info", "No speech could be recognized.");
                recognizer_activated = "False";
                activate_recognizer();
            }

        } catch (Exception e) {
            Log.i("info", "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void activate_recognizer() {
        if (recognizer_state.equals("active") && recognizer_activated.equals("False")) {
            Thread recognitionThread = new Thread(() -> {
                try {
                    recognizeSpeechOnce();
                } catch (Exception e) {
                    Log.e("RecognizerThread", "Error during speech recognition: " + e.getMessage(), e);
                }
            });
            recognitionThread.start();
        }
    }

    private void askGPTResponse(String userInput) {
        String memory = loadMemory();
        Map<String, String> values = new HashMap<>();
        values.put("MEMORY", memory);
        String systemMessage_final = fillTemplate_main(systemMessage, values);
        openAIClient.queryGPT(userInput, systemMessage_final, history_messages, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String jsonResponse = response.body().string();
                    try {
                        JSONObject jsonObject = new JSONObject(jsonResponse);
                        JSONArray choices = jsonObject.getJSONArray("choices");
                        String gptResponse = choices.getJSONObject(0).getJSONObject("message").getString("content");

                        Log.i("info", "GPT response: " + gptResponse);

                        // Convert the string to a JSONObject
                        JSONObject jsonGPT = new JSONObject(gptResponse);

                        String sentenceKey = jsonGPT.getString("sentence");
                        save_sentence("robot: " + sentenceKey);
                        Log.i("info", "KEY: " + sentenceKey);

                        String em = jsonGPT.getString("emotion");
                        set_emotion(em);

                        if (history_messages.length() >= 10) {
                            // Remove the first two elements
                            history_messages.remove(0);
                            history_messages.remove(0);
                        }

                        JSONObject message1 = new JSONObject();
                        message1.put("role", "user");
                        message1.put("content", userInput);
                        history_messages.put(message1);

                        sayText(sentenceKey, "robot");
                        set_emotion(em);
                        play_facial_event(em);
                        BuddySDK.UI.setMood(FacialExpression.NEUTRAL);
                        JSONObject message2 = new JSONObject();
                        message2.put("role", "assistant");
                        message2.put("content", gptResponse);
                        history_messages.put(message2);
                        activate_recognizer();

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Log.i("info", "GPT response error");
                        activate_recognizer();
                    }
                }
            }
        });
    }

    private void set_emotion(String em) {
        if (em.equals("Happy")) BuddySDK.UI.setFacialExpression(FacialExpression.HAPPY);
        else if (em.equals("Neutral")) BuddySDK.UI.setFacialExpression(FacialExpression.NEUTRAL);
        else if (em.equals("Love")) BuddySDK.UI.setFacialExpression(FacialExpression.LOVE);
        else if (em.equals("Surprised")) BuddySDK.UI.setFacialExpression(FacialExpression.SURPRISED);
        else if (em.equals("Sad")) BuddySDK.UI.setFacialExpression(FacialExpression.SAD);
        else if (em.equals("Scared")) BuddySDK.UI.setFacialExpression(FacialExpression.SCARED);
        else if (em.equals("Sick")) BuddySDK.UI.setFacialExpression(FacialExpression.SICK);
        else if (em.equals("Tired")) BuddySDK.UI.setFacialExpression(FacialExpression.TIRED);
        else if (em.equals("Grumpy")) BuddySDK.UI.setFacialExpression(FacialExpression.GRUMPY);
        else if (em.equals("Angry")) BuddySDK.UI.setFacialExpression(FacialExpression.ANGRY);
    }

    private void play_facial_event(String em) {
        if (em.equals("Smile")) BuddySDK.UI.playFacialEvent(FacialEvent.SMILE);
        else if (em.equals("blink right eye")) BuddySDK.UI.playFacialEvent(FacialEvent.BLINK_RIGHT_EYE);
        else if (em.equals("Awake")) BuddySDK.UI.playFacialEvent(FacialEvent.AWAKE);
    }

    /**
     * Synthesizes a sentence with the voice matching the given character.
     *
     * @param text  the sentence to be spoken
     * @param voice "wave" for the voice of the waves, "narrator" for the
     *              narrating voice, anything else for the robot's own voice
     */
    private void sayText(String text, String voice) {
        try {
            if (speaking.equals("False")) {
                SpeechConfig config = SpeechConfig.fromSubscription(SUBSCRIPTION_KEY, SERVICE_REGION);
                if (voice.equals("narrator")) {
                    config.setSpeechSynthesisVoiceName("en-US-AndrewNeural");
                } else if (voice.equals("wave")) {
                    config.setSpeechSynthesisVoiceName("en-US-EmmaNeural");
                } else {
                    config.setSpeechSynthesisVoiceName("en-US-AvaMultilingualNeural");
                }
                SpeechSynthesizer synthesizer = new SpeechSynthesizer(config);
                new Thread(() -> {
                    try {
                        Thread.sleep(500);
                        robotController.enable_yes(true);
                        robotController.start_autonomous_head_movements();
                        BuddySDK.UI.setLabialExpression(LabialExpression.SPEAK_NEUTRAL);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }

                }).start();
                speaking = "True";
                SpeechSynthesisResult result = synthesizer.SpeakText(text);
                BuddySDK.UI.setLabialExpression(LabialExpression.NO_EXPRESSION);
                robotController.enable_yes(false);
                result.close();
                synthesizer.close();
                speaking = "False";
            }

        } catch (Exception e) {
            Log.i("info", "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
