package com.example.wavesactivity;

import android.content.Context;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.VideoView;

import androidx.annotation.NonNull;

import com.bfr.buddy.usb.shared.IUsbCommadRsp;
import com.bfr.buddysdk.BuddySDK;
import com.bfr.buddysdk.services.companion.Task;
import com.bfr.buddysdk.services.companion.TaskCallback;
import com.google.android.exoplayer2.ui.PlayerView;

import java.io.File;

/**
 * Plays the pre-recorded interactive behaviours (BI) of the robot, either
 * through a plain VideoView or through the player view of the SDK.
 */
public class BIReader {

    private static final String TAG = "BIReader";
    /** Folder on the device where the behaviour files are stored. */
    private static final String BI_FOLDER = "/storage/emulated/0/Download/";

    private Context context;
    private ImageView imageView;
    private VideoView videoView;
    private PlayerView exoView; // ExoPlayer's PlayerView

    public BIReader(Context context, ImageView imageView, VideoView videoView, PlayerView exoView) {
        this.context = context;
        this.imageView = imageView;
        this.videoView = videoView;
        this.exoView = exoView; // Expects a PlayerView here rather than a generic Object
    }

    public void readBI(String biName) {
        String videoPath = BI_FOLDER + biName; // Path to the behaviour file
        Uri uri = Uri.parse(videoPath);

        // Set the video URI on the VideoView
        videoView.setVideoURI(uri);

        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                // Get the duration of the video
                int duration = videoView.getDuration();

                if (duration > 20000) {
                    videoView.seekTo(0);
                }

                // Start playback
                videoView.start();

                // Stop playback after the behaviour is over
                videoView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        videoView.pause();

                        videoView.setVisibility(View.GONE);
                        BuddySDK.USB.stopAllLed(new IUsbCommadRsp.Stub() {
                            @Override
                            public void onSuccess(String s) throws RemoteException {
                                Log.i(TAG, "Message received: " + s);
                            }

                            @Override
                            public void onFailed(String s) throws RemoteException {
                            }
                        });
                    }
                }, 32000);
            }
        });
    }

    public void readBI2(String biName) {
        // Get the path to the Downloads directory
        String docPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).toString();
        Log.i(TAG, "Path: " + docPath);

        // Build the full path of the file to be used
        String fileName = docPath + "/" + biName;
        Log.i(TAG, "File: " + fileName);
        File source = new File(fileName);

        exoView.setVisibility(View.VISIBLE);

        try {
            // Create the BI task with the proper file path and media views
            Task biTask = BuddySDK.Companion.createBITask(BI_FOLDER, exoView, imageView, true);
            biTask.start(new TaskCallback() {
                @Override
                public void onStarted() {
                    Log.d(TAG, "BI Task started");
                }

                @Override
                public void onSuccess(@NonNull String s) {
                    Log.d(TAG, "BI Task success: " + s);
                }

                @Override
                public void onCancel() {
                    Log.d(TAG, "BI Task cancelled");
                }

                @Override
                public void onError(@NonNull String s) {
                    Log.e(TAG, "BI Task error: " + s);
                }

                @Override
                public void onIntermediateResult(@NonNull String s) {
                    Log.e(TAG, "Intermediate result: " + s);
                }
            });

        } catch (Exception e) {
            // Log the exception to help with debugging if something goes wrong
            Log.e(TAG, "Error during BI Task creation", e);
        }
    }
}
