package com.example.wavesactivity;

import android.os.RemoteException;
import android.util.Log;

import androidx.annotation.NonNull;

import com.bfr.buddy.usb.shared.IUsbCommadRsp;
import com.bfr.buddysdk.BuddyActivity;
import com.bfr.buddysdk.BuddySDK;
import com.bfr.buddysdk.services.companion.TaskCallback;

import java.util.Random;

/**
 * Wrapper around the robot actuators: head motors, wheels and the built-in
 * emotional behaviours of the platform.
 */
public class RobotController extends BuddyActivity {
    public Boolean finished_yes;
    public Boolean finished_no;
    public Boolean active = true;
    public Boolean yes_active = false;
    public Boolean positive = false;

    private final TaskCallback behaviorCallback = new TaskCallback() {
        @Override
        public void onStarted() {
            Log.i("BI", "Started");
        }

        @Override
        public void onSuccess(@NonNull String s) {
            Log.i("BI", "[BI][TASK] success " + s);
        }

        @Override
        public void onCancel() {
            Log.i("BI", "[BI][TASK] cancelled");
        }

        @Override
        public void onError(@NonNull String s) {
            Log.e("BI", "[BI][TASK] error " + s);
        }

        @Override
        public void onIntermediateResult(@NonNull String s) {
            Log.d("BI", "[BI][TASK] intermediate result " + s);
        }
    };

    /** Runs one of the emotional behaviours available on the robot. */
    public void runBehaviour(String bi) {
        Log.i("BI", "Try running behaviour: " + bi);
        BuddySDK.Companion.createBICategoryTask(bi).start(behaviorCallback);
    }

    public int extract_random_angle(int min, int max) {
        Random random = new Random();
        return random.nextInt((max - min) + 1) + min;
    }

    public void enable_yes(Boolean yes) {
        yes_active = yes;
    }

    /**
     * Starts the idle head motion loop, so that the robot keeps looking alive
     * while it is listening or speaking.
     */
    public void start_autonomous_head_movements() {
        new Thread(() -> {
            active = true;
            finished_yes = false;
            finished_no = false;

            EnableYesMotor(1);
            EnableNoMotor(1);
            enableWheels(1, 1);
            finished_yes = false;
            finished_no = false;

            while (active) {
                if (yes_active) HeadSayYes(20, extract_random_angle(-15, 20));
                else finished_yes = true;
                int no_angle = extract_random_angle(-30, 30);
                HeadSayNo(20, no_angle);
                while (!finished_no || !finished_yes) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        Log.i("main", "Thread interrupted", e);
                    }
                }

                finished_yes = false;
                finished_no = false;
                if (yes_active) {
                    if (positive) {
                        rotateRobot(15, -10);
                        positive = false;
                    } else {
                        rotateRobot(15, 10);
                        positive = true;
                    }
                }
            }

            // Bring the head back to the home pose before leaving the loop.
            HeadSayYes(20, 0);
            HeadSayNo(20, 0);
            finished_yes = false;
            finished_no = false;
            while (!finished_no || !finished_yes) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Log.i("main", "Thread interrupted", e);
                }
            }
            Log.i("head yes post", BuddySDK.Actuators.getYesPosition() + "");
            Log.i("head no post", BuddySDK.Actuators.getNoPosition() + "");
        }).start();
    }

    public void stop_autonomous_movement() {
        active = false;
    }

    public void enableWheels(int turnOnLeftWheel, int turnOnRightWheel) {
        BuddySDK.USB.enableWheels(turnOnLeftWheel, turnOnRightWheel, new IUsbCommadRsp.Stub() {

            @Override
            public void onSuccess(String s) throws RemoteException {
                Log.i("W", "Wheels are enabled");
            }

            @Override
            public void onFailed(String s) throws RemoteException {
                Log.i("W", "Wheels enable failed: " + s);
            }
        });
    }

    /** Moves the robot forward or backward. */
    public void moveRobot(float speed, float distance) {
        BuddySDK.USB.moveBuddy(speed, distance, new IUsbCommadRsp.Stub() {

            @Override
            public void onSuccess(String s) throws RemoteException {
                Log.i("Move", "Move: success");
                if ("WHEEL_MOVE_FINISHED".equals(s)) {
                    Log.i("W", "Move completed successfully");
                }
            }

            @Override
            public void onFailed(String s) throws RemoteException {
                Log.i("Move", "Move: failed : " + s);
            }
        });
    }

    /** Rotates the robot in place. */
    public void rotateRobot(float speed, float degree) {
        BuddySDK.USB.rotateBuddy(speed, degree, new IUsbCommadRsp.Stub() {

            @Override
            public void onSuccess(String s) throws RemoteException {
                Log.i("RotateRobot", s);
                if ("WHEEL_MOVE_FINISHED".equals(s)) {
                    Log.i("W", "Rotation completed successfully");
                }
            }

            @Override
            public void onFailed(String s) throws RemoteException {
                Log.i("RotateRobot", "Rotation failed : " + s);
            }
        });
    }

    public void StopNo() {
        BuddySDK.USB.buddyStopNoMove(new IUsbCommadRsp.Stub() {
            @Override
            public void onSuccess(String s) throws RemoteException {
            }

            @Override
            public void onFailed(String s) throws RemoteException {
            }
        });
    }

    public void StopYes() {
        BuddySDK.USB.buddyStopYesMove(new IUsbCommadRsp.Stub() {
            @Override
            public void onSuccess(String s) throws RemoteException {
            }

            @Override
            public void onFailed(String s) throws RemoteException {
            }
        });
    }

    public void EnableNoMotor(int state) {
        BuddySDK.USB.enableNoMove(state, new IUsbCommadRsp.Stub() {
            @Override
            // The "no" motor was enabled successfully.
            public void onSuccess(String success) throws RemoteException {
                Log.i("Motor No", "Motor Enabled");
                finished_no = true;
            }

            @Override
            // The "no" motor could not be enabled.
            public void onFailed(String error) throws RemoteException {
                Log.i("Motor No", "No motor Enabled Failed");
            }
        });
    }

    public void EnableYesMotor(int state) {
        BuddySDK.USB.enableYesMove(state, new IUsbCommadRsp.Stub() {
            @Override
            public void onSuccess(String success) throws RemoteException {
                Log.i("Motor Yes", "YES Motor Enabled");
                finished_yes = true;
            }

            @Override
            public void onFailed(String error) throws RemoteException {
                Log.i("Motor Yes", "Yes motor Enabled Failed");
            }
        });
    }

    public void HeadSayNo(float speed, float angle) {
        BuddySDK.USB.buddySayNo(speed, angle, new IUsbCommadRsp.Stub() { // speed, angle and stub callback

            @Override
            public void onSuccess(String s) throws RemoteException {
                if ("NO_MOVE_FINISHED".equals(s)) {
                    finished_no = true;
                }
            }

            @Override
            public void onFailed(String s) throws RemoteException {
                Log.i("No head fail", s);
            }
        });
    }

    public void HeadSayYes(float speed, float angle) {
        BuddySDK.USB.buddySayYes(speed, angle, new IUsbCommadRsp.Stub() { // speed, angle and stub callback
            @Override
            public void onSuccess(String s) throws RemoteException {
                if ("YES_MOVE_FINISHED".equals(s)) {
                    finished_yes = true;
                }
            }

            @Override
            public void onFailed(String s) throws RemoteException {
                Log.i("Yes head fail", s);
            }
        });
    }
}
