package com.example.wavesactivity;

import android.util.Log;

import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Minimal client for the OpenAI chat completions endpoint.
 *
 * The API key and the organization identifier are supplied by the caller;
 * they are injected at build time from local.properties and are never stored
 * in this repository.
 */
public class OpenAIClient {
    private final String API_KEY;
    private final String ORGANIZATION_ID;
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static final String MODEL = "gpt-4o";
    private final OkHttpClient client;

    public OpenAIClient(String apiKey, String organizationId) {
        this.API_KEY = apiKey;
        this.ORGANIZATION_ID = organizationId;
        client = new OkHttpClient();
    }

    /** Sends a user turn together with the recent dialogue history. */
    public void queryGPT(String userInput, String systemMessage, JSONArray messages_history, Callback callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("model", MODEL);

            JSONArray messages = new JSONArray();

            // Add the system message as the first message
            JSONObject systemMsg = new JSONObject();
            systemMsg.put("role", "system");
            systemMsg.put("content", systemMessage);
            messages.put(systemMsg);

            // Append the message history
            for (int i = 0; i < messages_history.length(); i++) {
                messages.put(messages_history.getJSONObject(i));
            }

            // Add the new user message
            JSONObject userMsg = new JSONObject();
            userMsg.put("role", "user");
            userMsg.put("content", userInput);
            messages.put(userMsg);

            json.put("messages", messages);
            json.put("max_tokens", 150);

            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(API_URL)
                    .post(body)
                    .addHeader("Authorization", "Bearer " + API_KEY)
                    .addHeader("OpenAI-Organization", ORGANIZATION_ID)
                    .build();

            client.newCall(request).enqueue(callback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** Sends a single stateless turn, used by the episodic memory pipeline. */
    public void queryGPT2(String userInput, String systemMessage, Callback callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("model", MODEL);

            JSONArray messages = new JSONArray();

            // Add the system message as the first message
            JSONObject systemMsg = new JSONObject();
            systemMsg.put("role", "system");
            systemMsg.put("content", systemMessage);
            messages.put(systemMsg);

            // Add the new user message
            JSONObject userMsg = new JSONObject();
            userMsg.put("role", "user");
            userMsg.put("content", userInput);
            messages.put(userMsg);

            Log.i("system", "Sending " + messages.length() + " messages to the model");

            json.put("messages", messages);
            json.put("max_tokens", 150);

            RequestBody body = RequestBody.create(json.toString(), JSON);
            Request request = new Request.Builder()
                    .url(API_URL)
                    .post(body)
                    .addHeader("Authorization", "Bearer " + API_KEY)
                    .addHeader("OpenAI-Organization", ORGANIZATION_ID)
                    .build();

            client.newCall(request).enqueue(callback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
