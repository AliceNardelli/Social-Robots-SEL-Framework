package com.example.wavesactivity;

import com.bfr.buddysdk.BuddyApplication;

public class MainApplication extends BuddyApplication {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
