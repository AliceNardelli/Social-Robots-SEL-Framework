package com.example.wavesactivity;

import org.json.JSONException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;

/**
 * Thin wrapper around the OpenWeatherMap current-weather endpoint.
 *
 * The API key is injected at build time from local.properties and is never
 * stored in this repository.
 */
public class WeatherService {
    private static final String API_KEY = BuildConfig.WEATHER_API_KEY;
    private static final String BASE_URL = "https://api.openweathermap.org/data/2.5/";

    public static void getWeather(String country, final WeatherCallback callback) {
        OkHttpClient client = new OkHttpClient();
        String url = BASE_URL + "weather?q=" + country + "&appid=" + API_KEY + "&units=metric";

        Request request = new Request.Builder().url(url).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onFailure(e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String jsonData = response.body().string();
                    try {
                        callback.onSuccess(jsonData);
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    callback.onFailure("Request failed with code: " + response.code());
                }
            }
        });
    }

    public interface WeatherCallback {
        void onSuccess(String jsonResponse) throws JSONException;

        void onFailure(String errorMessage);
    }
}
